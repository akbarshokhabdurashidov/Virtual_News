package com.shakhrashidov.virtual_news.util.swipeDetector

interface SwipeActions {
    fun onSwipeLeft()
    fun onSwipeUp()
    fun onSwipeDown()
}