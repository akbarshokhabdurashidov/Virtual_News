package com.shakhrashidov.virtual_news.model

data class Source(
    val id: String,
    val name: String
)